corn
====

 Unicorn and multicorn. Experimental autocomplete implementation running as a trivial vertx vertical.

First run: 

  `unicorns.sh <IP ADDRESS>`

Then in another terminal run: 

  `multicorns.sh <IP ADDRESS>`

Using the same ip address for each. 

View unicorns.js to view the available words in the array. You can search/autocomplete on these.  

Open a web browser and enter the following in the url to experiment:  

`Show the search page`
http://192.168.5.30:8080  `

`Search for items with prefix shaun`
http://192.168.5.30:8080/search/shaun  `

`List all items`
http://192.168.5.30:8080/list  `

`Add an item`
http://192.168.5.30:8080/add/new%20item  `





